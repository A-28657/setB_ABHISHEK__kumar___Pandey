#include<stdio.h>
#include<stdlib.h>
#include<string.h>
char a[10][100],b[10][100],str[100];
void main ()
{
	FILE *fp;
	fp=fopen("setB_2.txt","r");
	int num=5,o;
	scanf("%s",str);

for(int n=0;n<num;n++)
{
	fscanf(fp,"%s",a[]);
	fscanf(fp,"%s",b[n]);
	if(strcmp(str,b[n]) == 0)
	o = i;
}
int count = 0;
for(int n=0;n<num;n++)
{
	if(strcmp(a[o],b[n]) == 0)
	count++;
}
printf("%d\n",count);
fclose(fp);
}
